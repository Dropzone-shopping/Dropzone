// product-detail.js - Lógica da página de detalhes do produto
document.addEventListener('DOMContentLoaded', function() {
    // Elementos da página
    const productDetailContainer = document.getElementById('product-detail');
    const loadingElement = document.querySelector('.loading');
    const productTemplate = document.getElementById('product-template');
    const relatedProductTemplate = document.getElementById('related-product-template');
    
    // Captura o ID do produto da URL
    const urlParams = new URLSearchParams(window.location.search);
    const productId = urlParams.get('id');
    
    if (!productId) {
        // Redireciona se não houver ID
        window.location.href = 'index.html';
        return;
    }
    
    // Busca o produto no banco de dados
    const product = productsDatabase.getProductById(productId);
    
    if (!product) {
        // Produto não encontrado
        productDetailContainer.innerHTML = `
            <div class="product-not-found">
                <h2>Produto não encontrado</h2>
                <p>O produto que você está procurando não está disponível.</p>
                <a href="index.html" class="btn">Voltar à loja</a>
            </div>
        `;
        loadingElement.style.display = 'none';
        return;
    }
    
    // Clona o template do produto
    const productNode = productTemplate.content.cloneNode(true);
    
    // Preenche os dados do produto
    fillProductData(productNode, product);
    
    // Adiciona o produto à página
    productDetailContainer.innerHTML = '';
    productDetailContainer.appendChild(productNode);
    loadingElement.style.display = 'none';
    
    // Inicializa os eventos
    initProductEvents();
    
    // Carrega produtos relacionados
    loadRelatedProducts(product.relatedProducts);
});

function fillProductData(productNode, product) {
    // Preenche informações básicas
    productNode.querySelector('.product-title').textContent = product.name;
    productNode.querySelector('.product-name-breadcrumb').textContent = product.name;
    productNode.querySelector('.category-link').textContent = product.category.charAt(0).toUpperCase() + product.category.slice(1);
    productNode.querySelector('.category-link').href = `index.html?category=${product.category}`;
    
    // Preenche preços
    const currentPrice = productNode.querySelector('.current-price');
    currentPrice.textContent = `${product.price.toLocaleString('pt-AO')} ${product.currency}`;
    
    const oldPrice = productNode.querySelector('.old-price');
    if (product.oldPrice) {
        oldPrice.textContent = `${product.oldPrice.toLocaleString('pt-AO')} ${product.currency}`;
        oldPrice.classList.remove('hidden');
        
        // Calcula desconto
        const discount = Math.round(((product.oldPrice - product.price) / product.oldPrice) * 100);
        const discountBadge = productNode.querySelector('.discount-badge');
        discountBadge.textContent = `-${discount}%`;
        discountBadge.classList.remove('hidden');
    }
    
    // Preenche SKU e disponibilidade
    productNode.querySelector('#product-code').textContent = product.sku;
    const availability = productNode.querySelector('.product-availability');
    if (product.stock > 0) {
        availability.textContent = `Em stock (${product.stock} unidades)`;
        availability.className = 'product-availability in-stock';
    } else {
        availability.textContent = 'Esgotado';
        availability.className = 'product-availability out-of-stock';
        productNode.querySelector('.add-to-cart-btn').disabled = true;
    }
    
    // Preenche avaliações
    productNode.querySelector('.average').textContent = product.rating.toFixed(1);
    productNode.querySelector('.rating-count').textContent = `(${product.reviewsCount} avaliações)`;
    
    // Atualiza estrelas da avaliação média
    updateRatingStars(productNode.querySelector('.average-rating .stars'), product.rating);
    
    // Preenche barras de avaliação
    const ratingBars = productNode.querySelector('.rating-bars');
    ratingBars.innerHTML = '';
    for (let i = 5; i >= 1; i--) {
        const count = product.reviews.filter(r => r.rating === i).length;
        const percentage = product.reviewsCount > 0 ? Math.round((count / product.reviewsCount) * 100) : 0;
        
        const bar = document.createElement('div');
        bar.className = 'rating-bar';
        bar.innerHTML = `
            <span>${i} estrelas</span>
            <div class="bar-container">
                <div class="bar" style="width: ${percentage}%"></div>
            </div>
            <span>${percentage}%</span>
        `;
        ratingBars.appendChild(bar);
    }
    
    // Preenche descrição
    productNode.querySelector('#full-description').innerHTML = product.fullDescription;
    
    // Preenche características
    const featuresList = productNode.querySelector('.features-list');
    featuresList.innerHTML = '';
    product.features.forEach(feature => {
        const li = document.createElement('li');
        li.innerHTML = `<i class="fas fa-check"></i> ${feature}`;
        featuresList.appendChild(li);
    });
    
    // Preenche especificações
    const specsTable = productNode.querySelector('.specs-table');
    specsTable.innerHTML = '';
    for (const [key, value] of Object.entries(product.specifications)) {
        const row = document.createElement('tr');
        row.innerHTML = `
            <th>${key}</th>
            <td>${value}</td>
        `;
        specsTable.appendChild(row);
    }
    
    // Preenche avaliações
    if (product.reviews.length > 0) {
        productNode.querySelector('.no-reviews').style.display = 'none';
        
        const reviewList = productNode.querySelector('#review-list');
        reviewList.innerHTML = '';
        
        product.reviews.forEach(review => {
            const reviewElement = document.createElement('div');
            reviewElement.className = 'review';
            reviewElement.innerHTML = `
                <div class="review-header">
                    <div class="review-author">${review.author}</div>
                    <div class="review-rating">
                        ${getRatingStars(review.rating)}
                    </div>
                    <div class="review-date">${review.date}</div>
                </div>
                <div class="review-content">
                    <p>${review.comment}</p>
                </div>
            `;
            reviewList.appendChild(reviewElement);
        });
    }
    
    // Preenche galeria de imagens
    const mainImage = productNode.querySelector('#main-product-image');
    mainImage.src = product.images[0];
    mainImage.alt = product.name;
    
    const thumbnailContainer = productNode.querySelector('#thumbnail-container');
    product.images.forEach((image, index) => {
        const thumbnail = document.createElement('div');
        thumbnail.className = `thumbnail ${index === 0 ? 'active' : ''}`;
        thumbnail.dataset.image = image;
        thumbnail.innerHTML = `<img src="${image}" alt="${product.name} - Miniatura ${index + 1}">`;
        thumbnailContainer.appendChild(thumbnail);
    });
    
    // Preenche opções de tamanho
    const sizeOptions = productNode.querySelector('.size-options');
    sizeOptions.innerHTML = '';
    product.sizes.forEach((size, index) => {
        const button = document.createElement('button');
        button.className = `size-option ${index === 0 ? 'active' : ''}`;
        button.textContent = size;
        sizeOptions.appendChild(button);
    });
    
    // Preenche opções de cor
    const colorOptions = productNode.querySelector('.color-options');
    colorOptions.innerHTML = '';
    product.colors.forEach((color, index) => {
        const button = document.createElement('button');
        button.className = `color-option ${index === 0 ? 'active' : ''}`;
        button.dataset.color = color.name;
        button.style.backgroundColor = color.code;
        if (color.code === '#FFFFFF') {
            button.style.border = '1px solid #eee';
        }
        colorOptions.appendChild(button);
    });
    
    // Atualiza link de afiliado
    productNode.querySelector('#affiliate-link').href = `affiliate.html?product=${product.id}`;
}

function loadRelatedProducts(relatedIds) {
    const relatedProducts = productsDatabase.getRelatedProducts(relatedIds);
    const relatedContainer = document.getElementById('related-products');
    
    if (!relatedProducts.length) {
        relatedContainer.innerHTML = '<p>Nenhum produto relacionado encontrado.</p>';
        return;
    }
    
    relatedContainer.innerHTML = '';
    
    relatedProducts.forEach(relatedProduct => {
        const relatedProductNode = relatedProductTemplate.content.cloneNode(true);
        const productElement = relatedProductNode.querySelector('.product');
        
        // Preenche dados do produto relacionado
        productElement.dataset.id = relatedProduct.id;
        
        const imageLink = productElement.querySelector('.product-image-link');
        imageLink.href = `detalhe-produto.html?id=${relatedProduct.id}`;
        
        const imageDiv = productElement.querySelector('.product-image');
        imageDiv.style.backgroundImage = `url('${relatedProduct.images[0]}')`;
        
        const nameLink = productElement.querySelector('.product-name-link');
        nameLink.href = `detalhe-produto.html?id=${relatedProduct.id}`;
        nameLink.querySelector('.product-name').textContent = relatedProduct.name;
        
        productElement.querySelector('.product-price').textContent = 
            `${relatedProduct.price.toLocaleString('pt-AO')} ${relatedProduct.currency}`;
        
        // Adiciona badge se existir
        const badgeElement = productElement.querySelector('.product-badge');
        if (relatedProduct.badges && relatedProduct.badges.length > 0) {
            badgeElement.textContent = relatedProduct.badges[0];
        } else {
            badgeElement.style.display = 'none';
        }
        
        // Atualiza avaliação
        updateRatingStars(productElement.querySelector('.product-rating'), relatedProduct.rating);
        
        // Atualiza link de afiliado
        productElement.querySelector('.affiliate-link').href = `affiliate.html?product=${relatedProduct.id}`;
        
        // Configura botão de compra
        productElement.querySelector('.buy-btn').addEventListener('click', function(e) {
            e.preventDefault();
            // Simulação de adição ao carrinho
            const cartCount = document.querySelector('.cart-count');
            let count = parseInt(cartCount.textContent || '0');
            count++;
            cartCount.textContent = count;
            cartCount.style.display = 'flex';
            
            alert(`${relatedProduct.name} adicionado ao carrinho!`);
        });
        
        relatedContainer.appendChild(relatedProductNode);
    });
}

function initProductEvents() {
    // Troca de imagens na galeria
    document.querySelectorAll('.thumbnail').forEach(thumb => {
        thumb.addEventListener('click', function() {
            const thumbnails = document.querySelectorAll('.thumbnail');
            thumbnails.forEach(t => t.classList.remove('active'));
            this.classList.add('active');
            
            const mainImage = document.getElementById('main-product-image');
            mainImage.src = this.dataset.image;
        });
    });
    
    // Troca de abas
    document.querySelectorAll('.tab-header').forEach(header => {
        header.addEventListener('click', function() {
            const tabId = this.dataset.tab;
            const tabHeaders = document.querySelectorAll('.tab-header');
            const tabContents = document.querySelectorAll('.tab-content');
            
            tabHeaders.forEach(h => h.classList.remove('active'));
            tabContents.forEach(c => c.classList.remove('active'));
            
            this.classList.add('active');
            document.getElementById(tabId).classList.add('active');
        });
    });
    
    // Seletor de quantidade
    document.querySelector('.quantity-minus').addEventListener('click', function(e) {
        e.preventDefault();
        const input = document.querySelector('.quantity-input');
        let value = parseInt(input.value);
        if (value > 1) {
            input.value = value - 1;
        }
    });
    
    document.querySelector('.quantity-plus').addEventListener('click', function(e) {
        e.preventDefault();
        const input = document.querySelector('.quantity-input');
        let value = parseInt(input.value);
        if (value < parseInt(input.max)) {
            input.value = value + 1;
        }
    });
    
    // Seleção de tamanho
    document.querySelectorAll('.size-option').forEach(option => {
        option.addEventListener('click', function(e) {
            e.preventDefault();
            document.querySelectorAll('.size-option').forEach(opt => opt.classList.remove('active'));
            this.classList.add('active');
        });
    });
    
    // Seleção de cor
    document.querySelectorAll('.color-option').forEach(option => {
        option.addEventListener('click', function(e) {
            e.preventDefault();
            document.querySelectorAll('.color-option').forEach(opt => opt.classList.remove('active'));
            this.classList.add('active');
        });
    });
    
    // Avaliação por estrelas
    document.querySelectorAll('.rating-input i').forEach(star => {
        star.addEventListener('click', function() {
            const rating = parseInt(this.dataset.rating);
            const ratingInput = document.getElementById('product-rating');
            ratingInput.value = rating;
            
            // Atualiza visualização
            const stars = document.querySelectorAll('.rating-input i');
            stars.forEach((s, index) => {
                if (index < rating) {
                    s.classList.remove('far');
                    s.classList.add('fas');
                } else {
                    s.classList.remove('fas');
                    s.classList.add('far');
                }
            });
        });
    });
    
    // Formulário de avaliação
    document.getElementById('review-form')?.addEventListener('submit', function(e) {
        e.preventDefault();
        alert('Avaliação enviada com sucesso! Obrigado por seu feedback.');
        this.reset();
        
        // Reset stars
        document.querySelectorAll('.rating-input i').forEach(star => {
            star.classList.remove('fas');
            star.classList.add('far');
        });
        document.getElementById('product-rating').value = '0';
    });
    
    // Compartilhamento nas redes sociais
    document.querySelectorAll('.social-share').forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            const network = this.dataset.network;
            const productName = document.querySelector('.product-title').textContent;
            const url = window.location.href;
            
            let shareUrl = '';
            switch(network) {
                case 'facebook':
                    shareUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`;
                    break;
                case 'twitter':
                    shareUrl = `https://twitter.com/intent/tweet?text=${encodeURIComponent(`Confira ${productName} no O Bazzar`)}&url=${encodeURIComponent(url)}`;
                    break;
                case 'whatsapp':
                    shareUrl = `https://wa.me/?text=${encodeURIComponent(`Confira ${productName} no O Bazzar: ${url}`)}`;
                    break;
                case 'instagram':
                    // Instagram não tem API direta, então usamos uma abordagem genérica
                    alert('Compartilhe manualmente no Instagram copiando o link do produto.');
                    return;
            }
            
            window.open(shareUrl, '_blank', 'width=600,height=400');
        });
    });
    
    // Adicionar ao carrinho
    document.querySelector('.add-to-cart-btn').addEventListener('click', function() {
        const productId = new URLSearchParams(window.location.search).get('id');
        const product = productsDatabase.getProductById(productId);
        const quantity = parseInt(document.querySelector('.quantity-input').value);
        const size = document.querySelector('.size-option.active')?.textContent || 'Único';
        const color = document.querySelector('.color-option.active')?.dataset.color || 'Padrão';
        
        // Simulação - na implementação real você usaria seu sistema de carrinho
        alert(`${quantity}x ${product.name} (${size}, ${color}) adicionado ao carrinho!`);
        
        // Atualiza contador do carrinho (simulação)
        const cartCount = document.querySelector('.cart-count');
        cartCount.textContent = parseInt(cartCount.textContent || '0') + quantity;
        cartCount.style.display = 'flex';
    });
    
    // Favoritos
    document.querySelector('.btn-wishlist').addEventListener('click', function() {
        const productId = new URLSearchParams(window.location.search).get('id');
        const product = productsDatabase.getProductById(productId);
        
        alert(`${product.name} adicionado aos favoritos!`);
        this.innerHTML = '<i class="fas fa-heart"></i> Favoritado';
        this.classList.add('favorited');
    });
}

// Funções auxiliares
function updateRatingStars(container, rating) {
    const stars = container.querySelectorAll('i');
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 >= 0.5;
    
    stars.forEach((star, index) => {
        if (index < fullStars) {
            star.className = 'fas fa-star';
        } else if (index === fullStars && hasHalfStar) {
            star.className = 'fas fa-star-half-alt';
        } else {
            star.className = 'far fa-star';
        }
    });
}

function getRatingStars(rating) {
    let stars = '';
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 >= 0.5;
    
    for (let i = 1; i <= 5; i++) {
        if (i <= fullStars) {
            stars += '<i class="fas fa-star"></i>';
        } else if (i === fullStars + 1 && hasHalfStar) {
            stars += '<i class="fas fa-star-half-alt"></i>';
        } else {
            stars += '<i class="far fa-star"></i>';
        }
    }
    
    return stars;
}

