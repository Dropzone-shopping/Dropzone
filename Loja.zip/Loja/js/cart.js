class ShoppingCart {
    constructor() {
        this.cart = [];
        this.total = 0;
        this.subtotal = 0;
        this.shipping = 0;
        this.init();
    }

    init() {
        this.loadCart();
        this.setupEventListeners();
        this.updateCartUI();
    }

    setupEventListeners() {
        // Botão do carrinho
        document.getElementById('cart-button').addEventListener('click', () => this.toggleCart());
        
        // Fechar carrinho
        document.getElementById('close-cart').addEventListener('click', () => this.toggleCart());
        document.getElementById('cart-overlay').addEventListener('click', () => this.toggleCart());
        
        // Adicionar ao carrinho
        document.querySelectorAll('.buy-btn, .add-to-cart-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const product = this.getProductData(btn);
                this.addToCart(product);
                this.showAddedToCartModal(product);
            });
        });
    }

    getProductData(button) {
        const productElement = button.closest('.product');
        return {
            id: productElement.dataset.id,
            name: productElement.querySelector('.product-name').textContent,
            price: parseFloat(productElement.dataset.price),
            image: productElement.querySelector('.product-image').style.backgroundImage.match(/url\(["']?([^"']*)["']?\)/)[1],
            quantity: 1
        };
    }

    toggleCart() {
        document.getElementById('cart-sidebar').classList.toggle('open');
        document.getElementById('cart-overlay').classList.toggle('open');
    }

    addToCart(product) {
        const existingItem = this.cart.find(item => item.id === product.id);
        
        if (existingItem) {
            existingItem.quantity += 1;
        } else {
            this.cart.push(product);
        }
        
        this.saveCart();
        this.updateCartUI();
    }

    removeFromCart(productId) {
        this.cart = this.cart.filter(item => item.id !== productId);
        this.saveCart();
        this.updateCartUI();
    }

    updateQuantity(productId, newQuantity) {
        const item = this.cart.find(item => item.id === productId);
        if (item) {
            item.quantity = parseInt(newQuantity);
            if (item.quantity <= 0) {
                this.removeFromCart(productId);
            } else {
                this.saveCart();
                this.updateCartUI();
            }
        }
    }

    calculateTotals() {
        this.subtotal = this.cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
        this.shipping = this.subtotal > 35000 ? 0 : 1500; // Frete grátis acima de 35.000 KZ
        this.total = this.subtotal + this.shipping;
    }

    saveCart() {
        localStorage.setItem('shoppingCart', JSON.stringify(this.cart));
    }

    loadCart() {
        const savedCart = localStorage.getItem('shoppingCart');
        if (savedCart) {
            this.cart = JSON.parse(savedCart);
            this.updateCartUI();
        }
    }

    updateCartUI() {
        this.calculateTotals();
        const cartItemsContainer = document.getElementById('cart-items');
        const cartCount = document.querySelector('.cart-count');
        
        // Atualizar contador
        const totalItems = this.cart.reduce((sum, item) => sum + item.quantity, 0);
        cartCount.textContent = totalItems;
        cartCount.style.display = totalItems > 0 ? 'flex' : 'none';
        
        // Atualizar lista de itens
        if (this.cart.length === 0) {
            cartItemsContainer.innerHTML = `
                <div class="empty-cart">
                    <i class="fas fa-shopping-cart"></i>
                    <p>Seu carrinho está vazio</p>
                    <a href="index.html" class="btn">Continuar Comprando</a>
                </div>
            `;
        } else {
            cartItemsContainer.innerHTML = this.cart.map(item => `
                <div class="cart-item" data-id="${item.id}">
                    <img src="${item.image}" alt="${item.name}">
                    <div class="cart-item-info">
                        <h4 class="cart-item-title">${item.name}</h4>
                        <div class="cart-item-price">${item.price.toLocaleString('pt-AO', {style:'currency', currency:'AOA'})}</div>
                        <div class="cart-item-quantity">
                            <button class="quantity-btn minus">-</button>
                            <input type="number" value="${item.quantity}" min="1">
                            <button class="quantity-btn plus">+</button>
                        </div>
                        <button class="remove-item">Remover</button>
                    </div>
                </div>
            `).join('');
            
            // Adicionar eventos aos botões de quantidade
            document.querySelectorAll('.cart-item .quantity-btn.minus').forEach(btn => {
                btn.addEventListener('click', (e) => {
                    const itemId = e.target.closest('.cart-item').dataset.id;
                    const input = e.target.nextElementSibling;
                    this.updateQuantity(itemId, parseInt(input.value) - 1);
                });
            });
            
            document.querySelectorAll('.cart-item .quantity-btn.plus').forEach(btn => {
                btn.addEventListener('click', (e) => {
                    const itemId = e.target.closest('.cart-item').dataset.id;
                    const input = e.target.previousElementSibling;
                    this.updateQuantity(itemId, parseInt(input.value) + 1);
                });
            });
            
            document.querySelectorAll('.cart-item input[type="number"]').forEach(input => {
                input.addEventListener('change', (e) => {
                    const itemId = e.target.closest('.cart-item').dataset.id;
                    this.updateQuantity(itemId, parseInt(e.target.value));
                });
            });
            
            document.querySelectorAll('.remove-item').forEach(btn => {
                btn.addEventListener('click', (e) => {
                    const itemId = e.target.closest('.cart-item').dataset.id;
                    this.removeFromCart(itemId);
                });
            });
        }
        
        // Atualizar totais
        document.getElementById('cart-subtotal').textContent = this.subtotal.toLocaleString('pt-AO', {style:'currency', currency:'AOA'});
        document.getElementById('cart-shipping').textContent = this.shipping === 0 ? 'Grátis' : this.shipping.toLocaleString('pt-AO', {style:'currency', currency:'AOA'});
        document.getElementById('cart-total').textContent = this.total.toLocaleString('pt-AO', {style:'currency', currency:'AOA'});
    }

    showAddedToCartModal(product) {
        // Criar modal temporário
        const modal = document.createElement('div');
        modal.className = 'added-to-cart-modal';
        modal.innerHTML = `
            <div class="modal-content">
                <h3>Adicionado ao carrinho!</h3>
                <div class="modal-product">
                    <img src="${product.image}" alt="${product.name}">
                    <div>
                        <h4>${product.name}</h4>
                        <p>${product.price.toLocaleString('pt-AO', {style:'currency', currency:'AOA'})}</p>
                    </div>
                </div>
                <div class="modal-actions">
                    <button class="btn continue-shopping">Continuar Comprando</button>
                    <a href="checkout.html" class="btn go-to-checkout">Finalizar Compra</a>
                </div>
            </div>
        `;
        
        document.body.appendChild(modal);
        
        // Fechar modal
        modal.querySelector('.continue-shopping').addEventListener('click', () => {
            document.body.removeChild(modal);
        });
        
        setTimeout(() => {
            if (document.body.contains(modal)) {
                document.body.removeChild(modal);
            }
        }, 5000);
    }
}

// Inicializar carrinho quando o DOM estiver pronto
document.addEventListener('DOMContentLoaded', () => {
    const cart = new ShoppingCart();
});

