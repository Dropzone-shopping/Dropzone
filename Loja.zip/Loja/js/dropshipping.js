// Configurações da API do AliExpress
const ALIEXPRESS_API_KEY = 'SUA_CHAVE_DE_API';
const AFFILIATE_ID = 'SEU_ID_DE_AFILIADO';

// Função para importar produtos
async function fetchAliExpressProducts(keywords, category) {
    try {
        const response = await fetch(`https://api.aliExpress.com/products?keywords=${encodeURIComponent(keywords)}&category=${category}&apiKey=${ALIEXPRESS_API_KEY}`);
        
        if (!response.ok) {
            throw new Error('Erro ao buscar produtos');
        }
        
        const data = await response.json();
        return data.products;
    } catch (error) {
        console.error('Erro na importação:', error);
        return [];
    }
}

// Evento de importação de produtos
document.getElementById('import-products')?.addEventListener('click', async () => {
    const keywords = document.getElementById('product-search').value;
    const category = document.getElementById('product-category').value;
    
    if (!keywords) {
        alert('Por favor, digite termos para busca');
        return;
    }
    
    const products = await fetchAliExpressProducts(keywords, category);
    
    if (products.length === 0) {
        alert('Nenhum produto encontrado com esses critérios');
        return;
    }
    
    displayImportedProducts(products);
});

// Exibir produtos importados
function displayImportedProducts(products) {
    const container = document.querySelector('.imported-products-list');
    container.innerHTML = '';
    
    products.forEach(product => {
        const productElement = document.createElement('div');
        productElement.className = 'product';
        productElement.innerHTML = `
            <div class="product-image" style="background-image: url('${product.image}')">
                <span class="product-badge">Novo</span>
                <div class="shipping-badge">
                    <i class="fas fa-ship"></i> Envio direto
                </div>
            </div>
            <div class="product-info">
                <h3 class="product-name">${product.title}</h3>
                <div class="product-price">${product.price} KZ</div>
                <button class="buy-btn" data-id="${product.id}">Comprar Agora</button>
                <a href="https://www.aliexpress.com/item/${product.id}.html?aff_fcid=${AFFILIATE_ID}" 
                   class="affiliate-link" target="_blank">Link de Afiliado</a>
            </div>
        `;
        
        container.appendChild(productElement);
    });
}

// Atualizar preços e estoque
async function updatePricesAndStock() {
    const products = document.querySelectorAll('.product');
    
    for (const product of products) {
        const productId = product.dataset.id;
        
        try {
            const response = await fetch(`https://api.aliExpress.com/stock-price/${productId}?apiKey=${ALIEXPRESS_API_KEY}`);
            const data = await response.json();
            
            if (data.price) {
                product.querySelector('.product-price').textContent = `${data.price} KZ`;
            }
            
            if (!data.inStock) {
                product.querySelector('.buy-btn').disabled = true;
                product.querySelector('.buy-btn').textContent = 'Esgotado';
            }
        } catch (error) {
            console.error(`Erro ao atualizar produto ${productId}:`, error);
        }
    }
}

// Atualizar a cada hora
setInterval(updatePricesAndStock, 3600000);

// Atualizar ao carregar a página
document.addEventListener('DOMContentLoaded', updatePricesAndStock);