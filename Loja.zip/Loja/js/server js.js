
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
require('dotenv').config();

const app = express();

// Conexão com MongoDB
mongoose.connect(process.env.MONGODB_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true
});

// Modelos
const Order = mongoose.model('Order', new mongoose.Schema({
  orderId: String,
  customer: Object,
  items: Array,
  subtotal: Number,
  shipping: Number,
  total: Number,
  status: String,
  paymentMethod: String,
  paymentStatus: String,
  trackingNumber: String,
  createdAt: { type: Date, default: Date.now }
}));

// Middleware
app.use(cors());
app.use(express.json());

// Rotas
app.post('/api/orders', async (req, res) => {
  try {
    const order = new Order(req.body);
    await order.save();
    
    // Integração com AliExpress (simulada)
    if (process.env.NODE_ENV === 'production') {
      await processAliExpressOrder(order);
    }
    
    res.status(201).send(order);
  } catch (error) {
    res.status(400).send(error);
  }
});

app.get('/api/orders/:id', async (req, res) => {
  try {
    const order = await Order.findOne({ orderId: req.params.id });
    if (!order) return res.status(404).send();
    res.send(order);
  } catch (error) {
    res.status(500).send();
  }
});

// Função simulada de processamento AliExpress
async function processAliExpressOrder(order) {
  console.log(`Processando pedido ${order.orderId} no AliExpress...`);
  // Aqui você implementaria a integração real com a API do AliExpress
}

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Servidor rodando na porta ${PORT}`);
});
