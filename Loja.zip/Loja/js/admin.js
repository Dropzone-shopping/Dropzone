document.addEventListener('DOMContentLoaded', function() {
    // Inicializar gráficos
    initCharts();
    
    // Carregar pedidos recentes
    loadRecentOrders();
    
    // Navegação do painel
    setupNavigation();
});

function initCharts() {
    // Gráfico de vendas
    const salesCtx = document.getElementById('sales-chart').getContext('2d');
    const salesChart = new Chart(salesCtx, {
        type: 'line',
        data: {
            labels: ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul'],
            datasets: [{
                label: 'Vendas Mensais (KZ)',
                data: [125000, 150000, 175000, 200000, 225000, 250000, 275000],
                backgroundColor: 'rgba(75, 192, 192, 0.2)',
                borderColor: 'rgba(75, 192, 192, 1)',
                borderWidth: 2,
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'top',
                }
            }
        }
    });
    
    // Gráfico de produtos
    const productsCtx = document.getElementById('products-chart').getContext('2d');
    const productsChart = new Chart(productsCtx, {
        type: 'doughnut',
        data: {
            labels: ['Camisetas', 'Calças', 'Acessórios', 'Calçados', 'Outros'],
            datasets: [{
                data: [35, 25, 20, 15, 5],
                backgroundColor: [
                    '#FF6384',
                    '#36A2EB',
                    '#FFCE56',
                    '#4BC0C0',
                    '#9966FF'
                ]
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'right',
                }
            }
        }
    });
}

async function loadRecentOrders() {
    try {
        // Simular chamada à API
        const orders = await mockFetchOrders();
        const tbody = document.querySelector('.recent-orders tbody');
        
        tbody.innerHTML = orders.map(order => `
            <tr>
                <td>${order.orderId}</td>
                <td>${order.customer}</td>
                <td>${new Date(order.date).toLocaleDateString('pt-AO')}</td>
                <td>${order.total.toLocaleString('pt-AO', {style:'currency', currency:'AOA'})}</td>
                <td><span class="status-badge status-${order.status}">${getStatusText(order.status)}</span></td>
                <td>
                    <button class="btn-action btn-view">Ver</button>
                    <button class="btn-action btn-edit">Editar</button>
                </td>
            </tr>
        `).join('');
    } catch (error) {
        console.error('Erro ao carregar pedidos:', error);
    }
}

function getStatusText(status) {
    const statusMap = {
        'pending': 'Pendente',
        'processing': 'Processando',
        'shipped': 'Enviado',
        'delivered': 'Entregue'
    };
    return statusMap[status] || status;
}

function setupNavigation() {
    const navLinks = document.querySelectorAll('.sidebar-nav a');
    
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Remover active de todos os links
            navLinks.forEach(l => l.parentNode.classList.remove('active'));
            
            // Adicionar active ao link clicado
            this.parentNode.classList.add('active');
            
            // Atualizar título da página
            const pageTitle = this.textContent.trim();
            document.getElementById('page-title').textContent = pageTitle;
            
            // Aqui você carregaria o conteúdo dinâmico da seção
            // loadSection(this.getAttribute('href').substring(1));
        });
    });
}

// Função simulada - substitua por chamada real à API
async function mockFetchOrders() {
    return new Promise((resolve) => {
        setTimeout(() => {
            resolve([
                {
                    orderId: 'ORD-123456',
                    customer: 'João Silva',
                    date: '2023-05-15T10:30:00Z',
                    total: 25500,
                    status: 'processing'
                },
                {
                    orderId: 'ORD-123455',
                    customer: 'Maria Sousa',
                    date: '2023-05-14T14:15:00Z',
                    total: 18500,
                    status: 'pending'
                },
                {
                    orderId: 'ORD-123454',
                    customer: 'Carlos Mendes',
                    date: '2023-05-13T09:45:00Z',
                    total: 32000,
                    status: 'shipped'
                },
                {
                    orderId: 'ORD-123453',
                    customer: 'Ana Pereira',
                    date: '2023-05-12T16:20:00Z',
                    total: 12750,
                    status: 'delivered'
                },
                {
                    orderId: 'ORD-123452',
                    customer: 'Pedro Costa',
                    date: '2023-05-11T11:10:00Z',
                    total: 42000,
                    status: 'processing'
                }
            ]);
        }, 1000);
    });
}

