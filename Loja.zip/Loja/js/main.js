document.addEventListener('DOMContentLoaded', function() {
    // ==================== SISTEMA DE USUÁRIOS ====================
    const users = JSON.parse(localStorage.getItem('ecommerce_users')) || [];
    let currentUser = JSON.parse(localStorage.getItem('current_user')) || null;

    // Elementos do DOM
    const authModal = document.getElementById('auth-modal');
    const closeAuth = document.getElementById('close-auth');
    const userIcon = document.getElementById('user-icon');
    const authTabs = document.querySelectorAll('.auth-tab');
    const authPanels = document.querySelectorAll('.auth-panel');
    const loginForm = document.getElementById('login-form');
    const registerForm = document.getElementById('register-form');
    const recoverForm = document.getElementById('recover-form');
    const loginError = document.getElementById('login-error');
    const registerError = document.getElementById('register-error');
    const recoverError = document.getElementById('recover-error');
    const recoverSuccess = document.getElementById('recover-success');
    const switchTabs = document.querySelectorAll('.switch-tab');

    // ==================== CARRINHO DE COMPRAS ====================
    const cartButton = document.getElementById('cart-button');
    const cartOverlay = document.getElementById('cart-overlay');
    const cartSidebar = document.getElementById('cart-sidebar');
    const closeCart = document.getElementById('close-cart');
    const cartItemsContainer = document.getElementById('cart-items');
    const cartSubtotal = document.getElementById('cart-subtotal');
    const cartShipping = document.getElementById('cart-shipping');
    const cartTotal = document.getElementById('cart-total');
    const buyButtons = document.querySelectorAll('.buy-btn');
    const cartCount = document.querySelector('.cart-count');

    let cart = JSON.parse(localStorage.getItem('cart')) || [];
    // Inicialização básica (se necessário)
document.addEventListener('DOMContentLoaded', function() {
    // Outras inicializações que não sejam do carrinho
});

    // ==================== FUNÇÕES UTILITÁRIAS ====================
    function showAlert(element, message, isError = true) {
        element.textContent = message;
        element.style.display = 'block';
        setTimeout(() => {
            element.style.display = 'none';
        }, 3000);
    }

    function updateCartCount() {
        const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
        cartCount.textContent = totalItems;
        cartCount.style.display = totalItems > 0 ? 'block' : 'none';
    }

    function showNotification(message) {
        const notification = document.createElement('div');
        notification.className = 'notification';
        notification.textContent = message;
        document.body.appendChild(notification);

        setTimeout(() => {
            notification.classList.add('show');
            setTimeout(() => {
                notification.classList.remove('show');
                setTimeout(() => notification.remove(), 300);
            }, 2000);
        }, 100);
    }

    // ==================== AUTENTICAÇÃO ====================
    // Abrir modal de autenticação
    userIcon.addEventListener('click', function(e) {
        e.preventDefault();
        authModal.style.display = 'flex';
    });

    // Fechar modal
    closeAuth.addEventListener('click', function() {
        authModal.style.display = 'none';
    });

    // Trocar entre abas
    authTabs.forEach(tab => {
        tab.addEventListener('click', function() {
            authTabs.forEach(t => t.classList.remove('active'));
            authPanels.forEach(p => p.classList.remove('active'));
            
            this.classList.add('active');
            document.getElementById(`${this.dataset.tab}-panel`).classList.add('active');
        });
    });

    // Alternar entre abas via links
    switchTabs.forEach(tab => {
        tab.addEventListener('click', function(e) {
            e.preventDefault();
            const targetTab = this.dataset.tab;
            
            authTabs.forEach(t => t.classList.remove('active'));
            authPanels.forEach(p => p.classList.remove('active'));
            
            document.querySelector(`.auth-tab[data-tab="${targetTab}"]`).classList.add('active');
            document.getElementById(`${targetTab}-panel`).classList.add('active');
        });
    });

    // Formulário de Login
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const email = document.getElementById('login-email').value;
            const password = document.getElementById('login-password').value;
            
            // Validação
            if (!email || !password) {
                showAlert(loginError, 'Preencha todos os campos');
                return;
            }
            
            // Verificar usuário
            const user = users.find(u => u.email === email && u.password === password);
            
            if (!user) {
                showAlert(loginError, 'Email ou senha incorretos');
                return;
            }
            
            // Login bem-sucedido
            currentUser = user;
            localStorage.setItem('current_user', JSON.stringify(currentUser));
            authModal.style.display = 'none';
            showNotification(`Bem-vindo de volta, ${email.split('@')[0]}!`);
        });
    }

    // Formulário de Cadastro
    if (registerForm) {
        registerForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const name = document.getElementById('register-name').value;
            const email = document.getElementById('register-email').value;
            const password = document.getElementById('register-password').value;
            const confirmPassword = document.getElementById('register-confirm').value;
            
            // Validações
            if (!name || !email || !password || !confirmPassword) {
                showAlert(registerError, 'Preencha todos os campos');
                return;
            }
            
            if (password.length < 6) {
                showAlert(registerError, 'A senha deve ter pelo menos 6 caracteres');
                return;
            }
            
            if (password !== confirmPassword) {
                showAlert(registerError, 'As senhas não coincidem');
                return;
            }
            
            if (users.some(u => u.email === email)) {
                showAlert(registerError, 'Este email já está cadastrado');
                return;
            }
            
            // Criar novo usuário
            const newUser = {
                id: Date.now(),
                name,
                email,
                password,
                isAffiliate: false, // Pode se tornar afiliado depois
                cart: []
            };
            
            users.push(newUser);
            localStorage.setItem('ecommerce_users', JSON.stringify(users));
            
            currentUser = newUser;
            localStorage.setItem('current_user', JSON.stringify(currentUser));
            
            authModal.style.display = 'none';
            showNotification(`Cadastro realizado com sucesso, ${name}!`);
        });
    }

    // Formulário de Recuperação
    if (recoverForm) {
        recoverForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const email = document.getElementById('recover-email').value;
            
            if (!email) {
                showAlert(recoverError, 'Digite seu email cadastrado');
                return;
            }
            
            // Simular envio de email (em produção, integrar com backend)
            showAlert(recoverSuccess, 'Enviamos um link de recuperação para seu email', false);
            setTimeout(() => {
                document.querySelector(`.auth-tab[data-tab="login"]`).click();
            }, 3000);
        });
    }

    // ==================== CARRINHO DE COMPRAS ====================
    // Abrir/fechar carrinho
    cartButton.addEventListener('click', function(e) {
        e.preventDefault();
        cartSidebar.classList.add('open');
        cartOverlay.classList.add('open');
        renderCartItems();
    });

    closeCart.addEventListener('click', function() {
        cartSidebar.classList.remove('open');
        cartOverlay.classList.remove('open');
    });

    cartOverlay.addEventListener('click', function() {
        cartSidebar.classList.remove('open');
        cartOverlay.classList.remove('open');
    });

    // Adicionar produto ao carrinho
    buyButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            const productElement = e.target.closest('.product');
            const productId = parseInt(productElement.dataset.id);
            const productName = productElement.querySelector('.product-name').textContent;
            const productPrice = parseFloat(productElement.querySelector('.product-price').textContent.replace(/\D/g, ''));
            const productImage = productElement.querySelector('.product-image').style.backgroundImage.slice(5, -2);
            
            // Verificar se o produto já está no carrinho
            const existingItem = cart.find(item => item.id === productId);
            
            if (existingItem) {
                existingItem.quantity += 1;
            } else {
                cart.push({
                    id: productId,
                    name: productName,
                    price: productPrice,
                    image: productImage,
                    quantity: 1
                });
            }
            
            // Salvar no localStorage
            localStorage.setItem('cart', JSON.stringify(cart));
            
            // Atualizar UI
            updateCartCount();
            showNotification(`${productName} foi adicionado ao carrinho!`);
            
            // Se o carrinho estiver aberto, atualizar os itens
            if (cartSidebar.classList.contains('open')) {
                renderCartItems();
            }
        });
    });

    // Renderizar itens do carrinho
    function renderCartItems() {
        cartItemsContainer.innerHTML = '';
        let subtotal = 0;
        
        if (cart.length === 0) {
            cartItemsContainer.innerHTML = '<p>Seu carrinho está vazio</p>';
            cartSubtotal.textContent = '0 KZ';
            cartShipping.textContent = '0 KZ';
            cartTotal.textContent = '0 KZ';
            return;
        }
        
        cart.forEach(item => {
            const itemTotal = item.price * item.quantity;
            subtotal += itemTotal;
            
            const cartItemElement = document.createElement('div');
            cartItemElement.className = 'cart-item';
            cartItemElement.innerHTML = `
                <img src="${item.image}" alt="${item.name}">
                <div class="cart-item-info">
                    <div class="cart-item-title">${item.name}</div>
                    <div class="cart-item-price">${itemTotal.toLocaleString('pt-AO')} KZ</div>
                    <div class="cart-item-quantity">Quantidade: ${item.quantity}</div>
                    <button class="remove-item" data-id="${item.id}">Remover</button>
                </div>
            `;
            
            cartItemsContainer.appendChild(cartItemElement);
        });
        
        // Calcular frete (exemplo fixo)
        const shipping = subtotal > 50000 ? 0 : 2500; // Frete grátis acima de 50.000 KZ
        
        // Atualizar totais
        cartSubtotal.textContent = `${subtotal.toLocaleString('pt-AO')} KZ`;
        cartShipping.textContent = shipping === 0 ? 'Grátis' : `${shipping.toLocaleString('pt-AO')} KZ`;
        cartTotal.textContent = `${(subtotal + shipping).toLocaleString('pt-AO')} KZ`;
        
        // Adicionar eventos aos botões de remover
        document.querySelectorAll('.remove-item').forEach(button => {
            button.addEventListener('click', function() {
                const itemId = parseInt(this.dataset.id);
                cart = cart.filter(item => item.id !== itemId);
                localStorage.setItem('cart', JSON.stringify(cart));
                updateCartCount();
                renderCartItems();
            });
        });
    }

    // ==================== INICIALIZAÇÃO ====================
    updateCartCount();

    // Verificar se há parâmetros de afiliado na URL
    const urlParams = new URLSearchParams(window.location.search);
    const affiliateId = urlParams.get('ref');
    
    if (affiliateId) {
        // Registrar clique de afiliado (simulado)
        console.log(`Clique registrado para afiliado: ${affiliateId}`);
        // Em produção, enviaria para o backend
    }
});

// Estilo para notificação
const notificationStyle = document.createElement('style');
notificationStyle.textContent = `
    .notification {
        position: fixed;
        bottom: 20px;
        right: 20px;
        background: #D4AF37;
        color: white;
        padding: 15px 25px;
        border-radius: 5px;
        box-shadow: 0 3px 10px rgba(0,0,0,0.2);
        transform: translateY(100px);
        opacity: 0;
        transition: all 0.3s ease;
        z-index: 1000;
    }
    .notification.show {
        transform: translateY(0);
        opacity: 1;
    }
`;
document.head.appendChild(notificationStyle);