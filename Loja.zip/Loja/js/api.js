const API_BASE_URL = process.env.NODE_ENV === 'development' 
  ? 'http://localhost:3000/api' 
  : 'https://api.obazzar.com/api';

export async function createOrder(orderData) {
  const response = await fetch(`${API_BASE_URL}/orders`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(orderData)
  });
  
  if (!response.ok) {
    throw new Error('Erro ao criar pedido');
  }
  
  return await response.json();
}

export async function getOrder(orderId) {
  const response = await fetch(`${API_BASE_URL}/orders/${orderId}`);
  
  if (!response.ok) {
    throw new Error('Erro ao buscar pedido');
  }
  
  return await response.json();
}

