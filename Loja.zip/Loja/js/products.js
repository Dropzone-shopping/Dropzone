// products.js - Banco de dados de produtos
const productsDatabase = {
    products: [
        {
            id: 1,
            name: "Camiseta Premium Masculina",
            category: "masculino",
            subcategory: "camisetas",
            price: 12500,
            oldPrice: 15000,
            currency: "KZ",
            images: [
                "produtos/adidas2.jpg",
                "produtos/adidas2-back.jpg",
                "produtos/adidas2-detail.jpg"
            ],
            badges: ["Novo"],
            rating: 4.7,
            reviewsCount: 42,
            sku: "AD-2023-BLK",
            stock: 5,
            description: "Camiseta premium em algodão egípcio 100%, com corte moderno e etiqueta removível para maior conforto. Ideal para uso casual ou esportivo.",
            fullDescription: "<p>A Camiseta Premium Masculina é fabricada com os mais altos padrões de qualidade. O tecido em algodão egípcio proporciona maciez incomparável e durabilidade superior. O corte moderno oferece caimento perfeito para o corpo masculino, valorizando sua silhueta.</p><p>Ideal para uso diário, a camiseta mantém sua forma e cor mesmo após múltiplas lavagens. A etiqueta removível garante conforto máximo sem irritações na pele.</p>",
            features: [
                "Tecido respirável e anti-odor",
                "Costura reforçada para maior durabilidade",
                "Lavagem à máquina sem desbotar"
            ],
            specifications: {
                "Material": "100% Algodão Egípcio",
                "Peso": "180 g/m²",
                "Origem": "Portugal",
                "Cores Disponíveis": "Preto, Branco, Dourado",
                "Tamanhos": "S, M, L, XL",
                "Cuidados": "Lavar a 30°C, não usar alvejante"
            },
            sizes: ["S", "M", "L", "XL"],
            colors: [
                { name: "Preto", code: "#000000" },
                { name: "Branco", code: "#FFFFFF" },
                { name: "Dourado", code: "#D4AF37" }
            ],
            reviews: [
                {
                    author: "João M.",
                    rating: 5,
                    date: "15/02/2023",
                    comment: "Excelente qualidade! O tecido é realmente muito macio e a camiseta tem um caimento perfeito. Comprei tamanho M e ficou exatamente como esperado."
                },
                {
                    author: "Carlos S.",
                    rating: 4,
                    date: "03/01/2023",
                    comment: "Muito boa, mas achei que poderia ser um pouco mais comprida. Fora isso, o material é de ótima qualidade e vale o investimento."
                }
            ],
            relatedProducts: [2, 3]
        },
        {
            id: 2,
            name: "Chapeu LV",
            category: "masculino",
            subcategory: "acessorios",
            price: 5000,
            oldPrice: null,
            currency: "KZ",
            images: ["produtos/lv.jpg"],
            badges: ["Compre-já"],
            rating: 4.5,
            reviewsCount: 18,
            sku: "LV-2023-HAT",
            stock: 8,
            description: "Chapéu de alta qualidade com logo LV, perfeito para complementar seu visual.",
            fullDescription: "<p>O Chapeu LV é um acessório essencial para quem busca estilo e proteção solar. Fabricado com materiais premium, oferece conforto e durabilidade excepcionais.</p><p>O design clássico combina com diversos estilos, desde looks casuais até mais elaborados. O logo LV discreto adiciona um toque de sofisticação.</p>",
            features: [
                "Ajuste confortável",
                "Proteção UV",
                "Material resistente à água"
            ],
            specifications: {
                "Material": "100% Algodão",
                "Tamanho": "Único (ajustável)",
                "Origem": "França",
                "Proteção UV": "UPF 50+"
            },
            sizes: ["Único"],
            colors: [
                { name: "Preto", code: "#000000" },
                { name: "Bege", code: "#F5F5DC" }
            ],
            reviews: [
                {
                    author: "Miguel T.",
                    rating: 5,
                    date: "22/03/2023",
                    comment: "Chapéu excelente! Muito confortável e o material é de alta qualidade."
                },
                {
                    author: "Ana K.",
                    rating: 4,
                    date: "10/03/2023",
                    comment: "Gostei muito, mas achei que poderia ter mais opções de cores."
                }
            ],
            relatedProducts: [1, 3]
        },
        {
            id: 3,
            name: "T-shirt Cactus Jack",
            category: "masculino",
            subcategory: "camisetas",
            price: 5700,
            oldPrice: 6500,
            currency: "KZ",
            images: ["produtos/t-jack.jpg"],
            badges: ["Novo"],
            rating: 4.8,
            reviewsCount: 27,
            sku: "CJ-2023-TS",
            stock: 3,
            description: "T-shirt oficial da marca Cactus Jack, coleção limitada.",
            fullDescription: "<p>A T-shirt Cactus Jack faz parte da coleção oficial da marca, com estampa exclusiva e qualidade premium. O algodão penteado garante maciez e durabilidade.</p><p>O corte oversized proporciona conforto e estilo urbano. Perfeita para quem busca um look despojado sem abrir mão da qualidade.</p>",
            features: [
                "Estampa de alta qualidade",
                "Corte oversized",
                "Algodão penteado"
            ],
            specifications: {
                "Material": "100% Algodão",
                "Peso": "160 g/m²",
                "Origem": "EUA",
                "Tamanhos": "S, M, L"
            },
            sizes: ["S", "M", "L"],
            colors: [
                { name: "Preto", code: "#000000" },
                { name: "Branco", code: "#FFFFFF" }
            ],
            reviews: [
                {
                    author: "Rui S.",
                    rating: 5,
                    date: "05/04/2023",
                    comment: "Perfeita! A estampa é linda e o tecido muito macio."
                },
                {
                    author: "Sofia N.",
                    rating: 5,
                    date: "28/03/2023",
                    comment: "Comprei para meu marido e ele adorou. O tamanho ficou perfeito."
                }
            ],
            relatedProducts: [1, 2]
        },
        {
            id: 4,
            name: "Vestido Elegante",
            category: "feminino",
            subcategory: "vestidos",
            price: 8900,
            oldPrice: 9900,
            currency: "KZ",
            images: ["produtos/vestido.jpg"],
            badges: ["Oferta"],
            rating: 4.6,
            reviewsCount: 35,
            sku: "VE-2023-BL",
            stock: 7,
            description: "Vestido elegante para ocasiões especiais, com corte que valoriza o corpo feminino.",
            fullDescription: "<p>O Vestido Elegante é a peça perfeita para eventos especiais. Com um corte que valoriza a silhueta feminina, oferece conforto e sofisticação.</p><p>O tecido fluído garante movimento e elegância, enquanto o design atemporal permite múltiplas ocasiões de uso.</p>",
            features: [
                "Tecido fluído e confortável",
                "Corte que valoriza a silhueta",
                "Versátil para diversas ocasiões"
            ],
            specifications: {
                "Material": "Poliéster e Elastano",
                "Tamanhos": "P, M, G",
                "Origem": "Brasil",
                "Cores Disponíveis": "Preto, Azul Marinho, Vermelho"
            },
            sizes: ["P", "M", "G"],
            colors: [
                { name: "Preto", code: "#000000" },
                { name: "Azul Marinho", code: "#000080" },
                { name: "Vermelho", code: "#FF0000" }
            ],
            reviews: [
                {
                    author: "Maria L.",
                    rating: 5,
                    date: "12/04/2023",
                    comment: "Amei o vestido! Ficou perfeito no meu corpo e recebi muitos elogios."
                },
                {
                    author: "Clara S.",
                    rating: 4,
                    date: "05/04/2023",
                    comment: "Muito bonito, só achei o tecido um pouco fino para o preço."
                }
            ],
            relatedProducts: [1, 2]
        }
    ],

    // Método para buscar um produto por ID
    getProductById: function(id) {
        return this.products.find(product => product.id == id);
    },

    // Método para buscar produtos relacionados
    getRelatedProducts: function(ids) {
        return this.products.filter(product => ids.includes(product.id));
    },

    // Método para buscar produtos por categoria
    getProductsByCategory: function(category, limit = 4) {
        const filtered = this.products.filter(product => product.category === category);
        return filtered.slice(0, limit);
    }
};

