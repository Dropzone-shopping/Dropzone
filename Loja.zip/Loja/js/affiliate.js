// Rastreamento de cliques em links de afiliado
document.querySelectorAll('.affiliate-link').forEach(link => {
    link.addEventListener('click', function(e) {
        e.preventDefault();
        const productId = this.getAttribute('data-product-id') || this.href.split('/item/')[1]?.split('.')[0];
        
        // Registrar o clique
        localStorage.setItem('lastAffiliateClick', JSON.stringify({
            productId,
            timestamp: new Date().getTime()
        }));
        
        // Redirecionar com ID de afiliado
        window.location.href = `https://www.aliexpress.com/item/${productId}.html?aff_fcid=${AFFILIATE_ID}`;
    });
});

// Verificar comissão ao carregar a página
window.addEventListener('load', () => {
    const lastClick = localStorage.getItem('lastAffiliateClick');
    
    if (lastClick) {
        const clickData = JSON.parse(lastClick);
        const now = new Date().getTime();
        
        // Considerar apenas cliques nas últimas 24 horas
        if (now - clickData.timestamp < 86400000) {
            registerAffiliateCommission(clickData.productId);
        }
        
        localStorage.removeItem('lastAffiliateClick');
    }
});

function registerAffiliateCommission(productId) {
    // Implementar lógica para registrar a comissão
    fetch('/api/register-commission', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ productId })
    });
}