document.addEventListener('DOMContentLoaded', function() {
    // Carregar itens do carrinho
    const cart = JSON.parse(localStorage.getItem('shoppingCart')) || [];
    const checkoutItems = document.getElementById('checkout-items');
    
    // Calcular totais
    const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const shipping = subtotal > 35000 ? 0 : 1500;
    const total = subtotal + shipping;
    
    // Preencher itens
    if (cart.length === 0) {
        window.location.href = 'index.html';
        return;
    }
    
    checkoutItems.innerHTML = cart.map(item => `
        <div class="checkout-item">
            <img src="${item.image}" alt="${item.name}">
            <div class="checkout-item-info">
                <h4 class="checkout-item-title">${item.name}</h4>
                <div class="checkout-item-price">${item.price.toLocaleString('pt-AO', {style:'currency', currency:'AOA'})}</div>
                <div class="checkout-item-quantity">Quantidade: ${item.quantity}</div>
            </div>
        </div>
    `).join('');
    
    // Atualizar totais
    document.getElementById('checkout-subtotal').textContent = subtotal.toLocaleString('pt-AO', {style:'currency', currency:'AOA'});
    document.getElementById('checkout-shipping').textContent = shipping === 0 ? 'Grátis' : shipping.toLocaleString('pt-AO', {style:'currency', currency:'AOA'});
    document.getElementById('checkout-total').textContent = total.toLocaleString('pt-AO', {style:'currency', currency:'AOA'});
    
    // Enviar formulário
    document.getElementById('shipping-form').addEventListener('submit', function(e) {
        e.preventDefault();
        
        // Coletar dados do formulário
        const formData = {
            nome: this.querySelector('input[type="text"]').value,
            email: this.querySelector('input[type="email"]').value,
            telefone: this.querySelector('input[type="tel"]').value,
            endereco: this.querySelectorAll('input[type="text"]')[1].value,
            provincia: this.querySelector('select').value,
            cidade: this.querySelectorAll('input[type="text"]')[2].value,
            bairro: this.querySelectorAll('input[type="text"]')[3].value,
            codigoPostal: this.querySelectorAll('input[type="text"]')[4].value,
            informacoes: this.querySelector('textarea').value
        };
        
        // Criar objeto de pedido
        const order = {
            orderId: 'ORD-' + Date.now(),
            customer: formData,
            items: cart,
            subtotal,
            shipping,
            total,
            status: 'pending',
            date: new Date().toISOString()
        };
        
        // Salvar pedido (em produção, enviaria para um backend)
        localStorage.setItem('currentOrder', JSON.stringify(order));
        
        // Redirecionar para página de pagamento
        window.location.href = 'payment.html';
    });
});