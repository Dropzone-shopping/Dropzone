document.addEventListener('DOMContentLoaded', function() {
    const trackButton = document.getElementById('track-order');
    const trackingResult = document.getElementById('tracking-result');
    
    trackButton.addEventListener('click', async function() {
        const orderNumber = document.getElementById('order-number').value.trim();
        const orderEmail = document.getElementById('order-email').value.trim();
        
        if (!orderNumber || !orderEmail) {
            alert('Por favor, preencha todos os campos');
            return;
        }
        
        try {
            // Mostrar estado de carregamento
            trackButton.disabled = true;
            trackButton.textContent = 'Buscando...';
            
            // Simular busca na API (substitua por chamada real)
            const order = await mockFetchOrder(orderNumber, orderEmail);
            
            // Preencher dados
            document.getElementById('tracking-order-id').textContent = order.orderId;
            document.getElementById('tracking-order-date').textContent = 
                new Date(order.createdAt).toLocaleDateString('pt-AO');
            document.getElementById('tracking-order-total').textContent = 
                order.total.toLocaleString('pt-AO', {style:'currency', currency:'AOA'});
            
            document.getElementById('tracking-shipping-address').textContent = 
                `${order.customer.endereco}, ${order.customer.bairro}, ${order.customer.cidade}`;
            
            document.getElementById('tracking-carrier').textContent = 
                order.trackingInfo?.carrier || 'AliExpress Standard Shipping';
            
            document.getElementById('tracking-number').textContent = 
                order.trackingInfo?.trackingNumber || 'Ainda não disponível';
            
            // Atualizar status
            updateStatusSteps(order.status);
            
            // Mostrar resultados
            trackingResult.classList.remove('hidden');
            
        } catch (error) {
            alert('Pedido não encontrado. Verifique os dados e tente novamente.');
            console.error(error);
        } finally {
            trackButton.disabled = false;
            trackButton.textContent = 'Rastrear Pedido';
        }
    });
    
    function updateStatusSteps(currentStatus) {
        const statusSteps = document.querySelectorAll('.status-step');
        const statusOrder = ['received', 'processing', 'shipped', 'in_transit', 'delivered'];
        
        statusSteps.forEach((step, index) => {
            if (statusOrder.indexOf(currentStatus) >= index) {
                step.classList.add('active');
            } else {
                step.classList.remove('active');
            }
        });
    }
    
    // Função simulada - substitua por chamada real à API
    async function mockFetchOrder(orderNumber, email) {
        return new Promise((resolve) => {
            setTimeout(() => {
                resolve({
                    orderId: orderNumber,
                    customer: {
                        nome: "João Silva",
                        endereco: "Rua Example, 123",
                        bairro: "Maianga",
                        cidade: "Luanda",
                        provincia: "Luanda",
                        email: email,
                        telefone: "+244 123 456 789"
                    },
                    items: [
                        {
                            name: "Camiseta Premium Masculina",
                            price: 12500,
                            quantity: 2
                        }
                    ],
                    subtotal: 25000,
                    shipping: 500,
                    total: 25500,
                    status: "processing",
                    paymentMethod: "credit_card",
                    createdAt: "2023-05-10T14:30:00Z",
                    trackingInfo: {
                        carrier: "AliExpress Standard Shipping",
                        trackingNumber: "RF123456789CN"
                    }
                });
            }, 1500);
        });
    }
});

