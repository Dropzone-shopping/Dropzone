// Todo o código de processamento de pedidos
app.post('/process-order', async (req, res) => {
  // Implementação completa
});